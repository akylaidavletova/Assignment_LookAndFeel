using DATAGOV_API_INTRO_8.Models;
using DATAGOV_API_INTRO_8.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;

namespace DATAGOV_API_INTRO_8.Controllers
{
    public class HomeController : Controller
    {
        private readonly ParksService _parksService;
        private readonly HttpClient _httpClient;

        // API Base URL and API Key
        static string BASE_URL = "http://api.weatherapi.com/v1";
        static string API_KEY = "072c9dda5c674eada60170029241011";//"028b29ed83f29f52492b5b2f98e7e7c7"; //"8HdmDFTNjPhuhhCueqaXRZDlear5aMZO4W9Q5pU9"; //"mdBybOievMdeX3eYSC0MhFu3U7xRV18xHAPG04qb";
        static string default_city = "Tampa";
        public HomeController(ParksService parksService)
        {
            _parksService = parksService;
            _httpClient = new HttpClient();
        }

        // READ: Index action to display all parks

        public async Task<IActionResult> Index(CityWeather mod)
        {
            string city="";
            if (mod.location != null) { city = mod.location.name; }
            else { city = default_city; }

            Console.WriteLine("Index action called: "+city);

            // If the data hasn't been fetched yet, fetch data from the API
            if (!_parksService.IsDataFetched() | city!=default_city)
            {
                Console.WriteLine("Fetching data from API...");
                //string apiPath = $"{BASE_URL}/parks?limit=30&api_key={API_KEY}";
                // string apiPath = $"{BASE_URL}/events?limit=20&api_key={API_KEY}";
                string apiPath = $"{BASE_URL}/current.json?key={API_KEY}&q={city}";

                HttpResponseMessage response = await _httpClient.GetAsync(apiPath);
                Console.WriteLine($"API response status code: {response.StatusCode}");

                if (response.IsSuccessStatusCode)
                {
                    string parksData = await response.Content.ReadAsStringAsync();
                    Console.WriteLine("Data fetched from API successfully.");
                    Console.WriteLine($"JSON Response: {parksData}");

                    // Deserialize the JSON data
                    // https://json2csharp.com/
                    //Parks parks = JsonConvert.DeserializeObject<Parks>(parksData);
                    CityWeather parks = JsonConvert.DeserializeObject<CityWeather>(parksData);
                    if (parks != null)
                    {
                        //Console.WriteLine($"Number of parks fetched: {parks.data.Count}");
                        _parksService.AddPark(parks);  // Store API data in memory
                        _parksService.MarkDataAsFetched();   // Mark data as fetched
                    }
                    else
                    {
                        Console.WriteLine("Deserialization failed or no data available.");
                    }
                }
                else
                {
                    Console.WriteLine("Failed to fetch data from API.");
                }
            }
            else
            {
                Console.WriteLine("Data already fetched.");
            }

            // Retrieve all parks from the service
            var parksList = _parksService.GetAllParks();
            //Console.WriteLine($"Number of parks in service: {parksList.Count}");

            // Return the list of parks to the view
            return View(parksList);
        }

        // CREATE: Handle both GET (display form) and POST (create park)
        [HttpGet, HttpPost]
        public IActionResult Create(string newCity)
        {
            Console.WriteLine("Create action called: " + newCity);

            if (HttpContext.Request.Method == "POST")
            {

                //_parksService.AddPark(newPark);  // Add the new park to the service
                //Console.WriteLine($"New park created: {newPark.fullName}");
                return RedirectToAction("Index");  // Redirect to Index after successful creation
            }

            return View();
        }

        // UPDATE: Handle both GET (show edit form) and POST (edit park)
        [HttpGet, HttpPost]
        
        // Privacy action for Privacy page
        public IActionResult Privacy()
        {
            Console.WriteLine("Privacy page accessed.");
            return View();
        }

        [HttpGet, HttpPost]
        public IActionResult AboutUs()
        {
            Console.WriteLine("AboutUs page accessed.");
            return View();
        }


    }
}
